import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-back-button',
  templateUrl: './back-button.page.html',
  styleUrls: ['./back-button.page.scss'],
  standalone: false,
})
export class BackButtonPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
