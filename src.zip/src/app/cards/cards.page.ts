import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.page.html',
  styleUrls: ['./cards.page.scss'],
  standalone: false,
})
export class CardsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
